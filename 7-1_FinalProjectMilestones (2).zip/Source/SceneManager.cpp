///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// Shader variable names
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_UseTextureName = "bUseTexture";
}

SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
}

SceneManager::~SceneManager()
{
    m_pShaderManager = NULL;
    delete m_basicMeshes;
    m_basicMeshes = NULL;
}

void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    glm::mat4 modelView;
    glm::mat4 scale = glm::scale(scaleXYZ);
    glm::mat4 rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
    glm::mat4 rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
    glm::mat4 rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
    glm::mat4 translation = glm::translate(positionXYZ);

    // Order: Scale -> Rotate -> Translate
    modelView = translation * rotationZ * rotationY * rotationX * scale;

    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
    }
}

void SceneManager::SetShaderColor(float r, float g, float b, float a)
{
    glm::vec4 currentColor(r, g, b, a);
    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
    }
}

void SceneManager::PrepareScene()
{
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadSphereMesh();
    m_basicMeshes->LoadTaperedCylinderMesh();
}

void SceneManager::RenderScene()
{
    glm::vec3 scaleXYZ;
    glm::vec3 positionXYZ;

    // --- 1. THE TABLE ---
    // Ground level
    scaleXYZ = glm::vec3(10.0f, 1.0f, 10.0f);
    positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.28f, 0.17f, 0.08f, 1.0f); // Dark wood color
    m_basicMeshes->DrawPlaneMesh();

    // ==========================================================================
    // THE LAMP (FIXED CONNECTION)
    // ==========================================================================

    float baseHeight = 0.3f;
    float poleHeight = 3.5f;

    // --- Part A: Lamp Base ---
    // Positioned at Y=0 so it sits on the table.
    scaleXYZ = glm::vec3(1.6f, baseHeight, 1.6f);
    positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.08f, 0.08f, 0.08f, 1.0f); // Black base
    m_basicMeshes->DrawCylinderMesh();

    // --- Part B: Lamp Pole ---
    // FIX: We set Y to 0.15. This is LOWER than the base height (0.3).
    // This forces the pole to "sink" halfway into the base, closing the gap.
    scaleXYZ = glm::vec3(0.1f, poleHeight, 0.1f);
    positionXYZ = glm::vec3(0.0f, 0.15f, 0.0f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.08f, 0.08f, 0.08f, 1.0f); // Black pole
    m_basicMeshes->DrawCylinderMesh();

    // --- Part C: Lamp Bulb ---
    // Top of pole is at 0.15 (position) + 3.5 (height) = 3.65.
    scaleXYZ = glm::vec3(0.4f, 0.4f, 0.4f);
    positionXYZ = glm::vec3(0.0f, 3.65f, 0.0f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(1.0f, 1.0f, 0.8f, 1.0f); // Warm bulb glow
    m_basicMeshes->DrawSphereMesh();

    // --- Part D: Lamp Shade ---
    // Positioned to surround the bulb and pole top.
    scaleXYZ = glm::vec3(2.2f, 4.0f, 2.2f);
    positionXYZ = glm::vec3(0.0f, 3.2f, 0.0f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.95f, 0.95f, 0.95f, 1.0f); // White shade
    m_basicMeshes->DrawTaperedCylinderMesh();
}