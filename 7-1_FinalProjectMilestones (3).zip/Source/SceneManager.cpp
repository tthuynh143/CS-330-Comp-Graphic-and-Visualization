
#include "SceneManager.h"
#include <glm/gtx/transform.hpp>

namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_UseTextureName = "bUseTexture";
}

SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
}

void SceneManager::SetTransformations(glm::vec3 scaleXYZ, float Xrot, float Yrot, float Zrot, glm::vec3 posXYZ)
{
	glm::mat4 model = glm::translate(posXYZ) * glm::rotate(glm::radians(Zrot), glm::vec3(0, 0, 1)) *
		glm::rotate(glm::radians(Yrot), glm::vec3(0, 1, 0)) *
		glm::rotate(glm::radians(Xrot), glm::vec3(1, 0, 0)) *
		glm::scale(scaleXYZ);

	if (m_pShaderManager != nullptr)
		m_pShaderManager->setMat4Value(g_ModelName, model);
}

void SceneManager::SetShaderColor(float r, float g, float b, float a)
{
	if (m_pShaderManager != nullptr)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(r, g, b, a));
	}
}

void SceneManager::PrepareScene()
{
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
}

void SceneManager::RenderScene()
{
	// 1. THE TABLE (PLANE)
	SetTransformations(glm::vec3(10.0f, 1.0f, 10.0f), 0.0f, 0.0f, 0.0f, glm::vec3(0.0f, 0.0f, 0.0f));
	SetShaderColor(0.28f, 0.17f, 0.08f, 1.0f); // Dark wood brown
	m_basicMeshes->DrawPlaneMesh();

	// 2. THE LAMP
	// Base
	SetTransformations(glm::vec3(1.6f, 0.3f, 1.6f), 0.0f, 0.0f, 0.0f, glm::vec3(0.0f, 0.0f, 0.0f));
	SetShaderColor(0.08f, 0.08f, 0.08f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// Pole
	SetTransformations(glm::vec3(0.1f, 3.5f, 0.1f), 0.0f, 0.0f, 0.0f, glm::vec3(0.0f, 0.15f, 0.0f));
	m_basicMeshes->DrawCylinderMesh();

	// Bulb
	SetTransformations(glm::vec3(0.4f, 0.4f, 0.4f), 0.0f, 0.0f, 0.0f, glm::vec3(0.0f, 3.65f, 0.0f));
	SetShaderColor(1.0f, 1.0f, 0.8f, 1.0f);
	m_basicMeshes->DrawSphereMesh();

	// Shade
	SetTransformations(glm::vec3(2.2f, 4.0f, 2.2f), 0.0f, 0.0f, 0.0f, glm::vec3(0.0f, 3.2f, 0.0f));
	SetShaderColor(0.95f, 0.95f, 0.95f, 1.0f);
	m_basicMeshes->DrawTaperedCylinderMesh();
}