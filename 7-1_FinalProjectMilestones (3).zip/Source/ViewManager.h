#pragma once

#include "ShaderManager.h"
#include "camera.h"
#include "GLFW/glfw3.h"

class ViewManager
{
public:
    ViewManager(ShaderManager* pShaderManager);
    ~ViewManager();

    // Creates the main window and captures the mouse
    GLFWwindow* CreateDisplayWindow(const char* windowTitle);

    // Updates matrices and processes frame-based movement
    void PrepareSceneView();

    // Static callbacks required by GLFW
    static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);
    static void Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset);

private:
    void ProcessKeyboardEvents();

    GLFWwindow* m_pWindow;
    ShaderManager* m_pShaderManager;
};