#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include "SceneManager.h"
#include "ViewManager.h"
#include "ShaderManager.h"

int main() {
    if (!glfwInit()) return -1;

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    ShaderManager* shaderMgr = new ShaderManager();
    ViewManager* viewMgr = new ViewManager(shaderMgr);
    GLFWwindow* window = viewMgr->CreateDisplayWindow("7-1 Final Project: Desk Scene");

    if (!window) { glfwTerminate(); return -1; }

    glewInit();
    glEnable(GL_DEPTH_TEST);

    shaderMgr->LoadShaders("shaders/vertexShader.glsl", "shaders/fragmentShader.glsl");
    shaderMgr->use();

    SceneManager* sceneMgr = new SceneManager(shaderMgr);
    sceneMgr->PrepareScene();

    while (!glfwWindowShouldClose(window)) {
        // SETTING BACKGROUND TO PURE BLACK
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        viewMgr->PrepareSceneView();
        sceneMgr->RenderScene();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    delete sceneMgr; delete viewMgr; delete shaderMgr;
    glfwTerminate();
    return 0;
}