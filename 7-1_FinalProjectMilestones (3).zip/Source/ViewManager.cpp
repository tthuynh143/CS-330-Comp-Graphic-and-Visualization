#include "ViewManager.h"

namespace {
    Camera* g_pCamera = nullptr;
    float gLastX = 500.0f, gLastY = 400.0f;
    bool gFirstMouse = true;
    float gDeltaTime = 0.0f, gLastFrame = 0.0f;
    bool bOrtho = false;
}

ViewManager::ViewManager(ShaderManager* pShaderManager) {
    m_pShaderManager = pShaderManager;
    g_pCamera = new Camera(glm::vec3(0.0f, 4.0f, 12.0f));
}

ViewManager::~ViewManager() { delete g_pCamera; }

void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xpos, double ypos) {
    if (gFirstMouse) {
        gLastX = (float)xpos; gLastY = (float)ypos;
        gFirstMouse = false; return;
    }

    float xoffset = (float)xpos - gLastX;
    float yoffset = gLastY - (float)ypos;
    gLastX = (float)xpos; gLastY = (float)ypos;

    // Smooth sensitivity
    float sensitivity = 0.08f;
    xoffset *= sensitivity;
    yoffset *= sensitivity;

    g_pCamera->ProcessMouseMovement(xoffset, yoffset);
}

void ViewManager::Mouse_Scroll_Callback(GLFWwindow* window, double xoffset, double yoffset) {
    g_pCamera->MovementSpeed += (float)yoffset;
    if (g_pCamera->MovementSpeed < 0.1f) g_pCamera->MovementSpeed = 0.1f;
}

GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle) {
    m_pWindow = glfwCreateWindow(1000, 800, windowTitle, NULL, NULL);
    if (!m_pWindow) return NULL;
    glfwMakeContextCurrent(m_pWindow);

    // UNCOMMENT the line below for the final version to hide the cursor:
    // glfwSetInputMode(m_pWindow, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    glfwSetCursorPosCallback(m_pWindow, Mouse_Position_Callback);
    glfwSetScrollCallback(m_pWindow, Mouse_Scroll_Callback);
    return m_pWindow;
}

void ViewManager::PrepareSceneView() {
    float currentFrame = (float)glfwGetTime();
    gDeltaTime = currentFrame - gLastFrame;
    gLastFrame = currentFrame;

    // Reinforce ESC key logic
    if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(m_pWindow, true);

    // WASDQE Controls
    if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS) g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS) g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS) g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS) g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS) g_pCamera->Position += g_pCamera->Up * g_pCamera->MovementSpeed * gDeltaTime;
    if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS) g_pCamera->Position -= g_pCamera->Up * g_pCamera->MovementSpeed * gDeltaTime;

    // Projection Controls
    if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS) bOrtho = false;
    if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS) bOrtho = true;

    glm::mat4 projection;
    if (bOrtho) {
        float scale = 8.0f;
        projection = glm::ortho(-scale * 1.25f, scale * 1.25f, -scale, scale, 0.1f, 100.0f);
    }
    else {
        projection = glm::perspective(glm::radians(g_pCamera->Zoom), 1000.0f / 800.0f, 0.1f, 100.0f);
    }

    m_pShaderManager->setMat4Value("view", g_pCamera->GetViewMatrix());
    m_pShaderManager->setMat4Value("projection", projection);
}